/* ==========================================================================
   Иллюстрации сайта: 30 иконок словаря + сцена для первого экрана + UI-иконки.
   Всё нарисовано вручную в SVG и встроено в документ — сайт не зависит
   от внешних картинок и работает без интернета.
   Цвета берутся из CSS-переменных (--g, --g-soft, --ink, --card), поэтому
   одна и та же иконка подстраивается под цвет своей подгруппы.
   ========================================================================== */
window.ICONS = (function () {
  'use strict';

  var SPRITE =
    '<svg id="icon-sprite" aria-hidden="true" focusable="false" ' +
      'style="position:absolute;width:0;height:0;overflow:hidden;pointer-events:none">' +

    /* ---------- 1. торговля: обмен товара --------------------------------- */
    '<symbol id="ic-trade" viewBox="0 0 320 240">' +
      '<circle cx="160" cy="126" r="86" fill="var(--g-soft)" opacity=".5"/>' +
      '<path d="M72 70h168" stroke="var(--g)" stroke-width="11" stroke-linecap="round"/>' +
      '<path d="M238 70l-24-14v28z" fill="var(--g)"/>' +
      '<path d="M248 198H80" stroke="var(--g)" stroke-width="11" stroke-linecap="round"/>' +
      '<path d="M82 198l24-14v28z" fill="var(--g)"/>' +
      '<path d="M112 108l20-14h96l-20 14z" fill="var(--g)"/>' +
      '<rect x="112" y="108" width="96" height="64" rx="5" fill="var(--ink)"/>' +
      '<path d="M212 94l20-14v64l-20 14z" fill="var(--g-soft)"/>' +
      '<rect x="152" y="94" width="12" height="78" fill="var(--card)" opacity=".92"/>' +
      '<path d="M164 94h12l-12 14z" fill="var(--card)" opacity=".5"/>' +
    '</symbol>' +

    /* ---------- 2. рынок --------------------------------------------------- */
    '<symbol id="ic-market" viewBox="0 0 320 240">' +
      '<circle cx="160" cy="126" r="86" fill="var(--g-soft)" opacity=".5"/>' +
      '<circle cx="94" cy="94" r="22" fill="var(--g)"/>' +
      '<circle cx="138" cy="94" r="22" fill="var(--g)"/>' +
      '<circle cx="182" cy="94" r="22" fill="var(--g)"/>' +
      '<circle cx="226" cy="94" r="22" fill="var(--g)"/>' +
      '<rect x="72" y="66" width="176" height="28" fill="var(--g)"/>' +
      '<rect x="112" y="66" width="8" height="28" fill="var(--card)" opacity=".45"/>' +
      '<rect x="156" y="66" width="8" height="28" fill="var(--card)" opacity=".45"/>' +
      '<rect x="200" y="66" width="8" height="28" fill="var(--card)" opacity=".45"/>' +
      '<rect x="82" y="94" width="9" height="94" fill="var(--ink)"/>' +
      '<rect x="229" y="94" width="9" height="94" fill="var(--ink)"/>' +
      '<rect x="96" y="132" width="54" height="28" rx="3" fill="var(--ink)"/>' +
      '<path d="M96 140h54M96 150h54" stroke="var(--card)" stroke-width="2.5" opacity=".35"/>' +
      '<circle cx="108" cy="126" r="7" fill="var(--g)"/>' +
      '<circle cx="124" cy="126" r="7" fill="var(--g)"/>' +
      '<circle cx="140" cy="126" r="7" fill="var(--g)"/>' +
      '<rect x="168" y="136" width="50" height="24" rx="3" fill="var(--ink)"/>' +
      '<circle cx="180" cy="131" r="6" fill="var(--g)"/>' +
      '<circle cx="196" cy="131" r="6" fill="var(--g)"/>' +
      '<circle cx="212" cy="131" r="6" fill="var(--g)"/>' +
      '<rect x="68" y="160" width="184" height="14" rx="3" fill="var(--ink)"/>' +
      '<rect x="76" y="174" width="168" height="30" fill="var(--g-soft)"/>' +
      '<path d="M118 174v30M160 174v30M202 174v30" stroke="var(--ink)" stroke-width="2.5" opacity=".25"/>' +
    '</symbol>' +

    /* ---------- 3. магазин ------------------------------------------------- */
    '<symbol id="ic-shop" viewBox="0 0 320 240">' +
      '<circle cx="160" cy="126" r="86" fill="var(--g-soft)" opacity=".5"/>' +
      '<rect x="86" y="58" width="148" height="130" rx="8" fill="var(--card)" stroke="var(--ink)" stroke-width="6"/>' +
      '<rect x="116" y="44" width="88" height="20" rx="5" fill="var(--ink)"/>' +
      '<rect x="130" y="51" width="34" height="6" rx="3" fill="var(--g)"/>' +
      '<circle cx="94" cy="96" r="16" fill="var(--g)"/>' +
      '<circle cx="126" cy="96" r="16" fill="var(--g)"/>' +
      '<circle cx="158" cy="96" r="16" fill="var(--g)"/>' +
      '<circle cx="190" cy="96" r="16" fill="var(--g)"/>' +
      '<circle cx="222" cy="96" r="16" fill="var(--g)"/>' +
      '<rect x="78" y="74" width="164" height="22" fill="var(--g)"/>' +
      '<rect x="102" y="112" width="62" height="52" rx="4" fill="var(--g-tint)" stroke="var(--ink)" stroke-width="4"/>' +
      '<path d="M102 138h62" stroke="var(--ink)" stroke-width="3.5"/>' +
      '<circle cx="116" cy="127" r="6" fill="var(--g)"/>' +
      '<rect x="128" y="121" width="10" height="10" rx="2" fill="var(--g)"/>' +
      '<rect x="144" y="122" width="10" height="9" rx="2" fill="var(--g)"/>' +
      '<circle cx="116" cy="150" r="6" fill="var(--g)"/>' +
      '<rect x="128" y="144" width="22" height="11" rx="2" fill="var(--g)"/>' +
      '<rect x="178" y="124" width="42" height="64" rx="3" fill="var(--ink)"/>' +
      '<circle cx="186" cy="156" r="3.5" fill="var(--card)"/>' +
      '<rect x="94" y="188" width="128" height="8" rx="4" fill="var(--ink)"/>' +
    '</symbol>' +

    /* ---------- 4. покупатель ---------------------------------------------- */
    '<symbol id="ic-buyer" viewBox="0 0 320 240">' +
      '<circle cx="160" cy="126" r="86" fill="var(--g-soft)" opacity=".5"/>' +
      '<circle cx="146" cy="72" r="21" fill="var(--ink)"/>' +
      '<rect x="116" y="98" width="58" height="76" rx="18" fill="var(--g)"/>' +
      '<path d="M138 100l8 13 8-13z" fill="var(--card)"/>' +
      '<rect x="168" y="116" width="12" height="38" rx="6" fill="var(--ink)"/>' +
      '<path d="M186 130h70l-12 44h-46z" fill="var(--g-soft)" stroke="var(--ink)" stroke-width="5" stroke-linejoin="round"/>' +
      '<path d="M208 130c0-16 26-16 26 0" fill="none" stroke="var(--ink)" stroke-width="5"/>' +
      '<path d="M206 144v22M220 144v22M234 144v22" stroke="var(--ink)" stroke-width="3" opacity=".4"/>' +
      '<g transform="rotate(-8 91 150)">' +
        '<rect x="74" y="128" width="34" height="44" rx="3" fill="var(--card)" stroke="var(--ink)" stroke-width="4"/>' +
        '<path d="M82 140h18M82 150h18M82 160h12" stroke="var(--g)" stroke-width="3"/>' +
      '</g>' +
    '</symbol>' +

    /* ---------- 5. продавец ------------------------------------------------ */
    '<symbol id="ic-seller" viewBox="0 0 320 240">' +
      '<circle cx="160" cy="126" r="86" fill="var(--g-soft)" opacity=".5"/>' +
      '<circle cx="160" cy="82" r="20" fill="var(--ink)"/>' +
      '<rect x="128" y="104" width="64" height="62" rx="18" fill="var(--g)"/>' +
      '<rect x="142" y="122" width="36" height="44" rx="4" fill="var(--card)"/>' +
      '<rect x="186" y="116" width="12" height="26" rx="6" fill="var(--ink)"/>' +
      '<rect x="100" y="132" width="32" height="12" rx="6" fill="var(--ink)"/>' +
      '<rect x="72" y="136" width="36" height="26" rx="3" fill="var(--card)" stroke="var(--ink)" stroke-width="3"/>' +
      '<path d="M80 144h20M80 152h12" stroke="var(--g)" stroke-width="3"/>' +
      '<rect x="62" y="166" width="196" height="16" rx="4" fill="var(--ink)"/>' +
      '<rect x="70" y="182" width="180" height="26" fill="var(--g-soft)"/>' +
      '<path d="M112 182v26M160 182v26M208 182v26" stroke="var(--ink)" stroke-width="2.5" opacity=".25"/>' +
    '</symbol>' +

    /* ---------- 6. ярмарка ------------------------------------------------- */
    '<symbol id="ic-fair" viewBox="0 0 320 240">' +
      '<circle cx="160" cy="126" r="86" fill="var(--g-soft)" opacity=".5"/>' +
      '<path d="M46 52Q160 86 274 50" fill="none" stroke="var(--ink)" stroke-width="3" opacity=".6"/>' +
      '<path d="M62 59l14 2-6 24z" fill="var(--g)"/>' +
      '<path d="M108 67l14 1-6 24z" fill="var(--ink)"/>' +
      '<path d="M150 71l14 1-5 24z" fill="var(--g)"/>' +
      '<path d="M194 67l14-1-7 24z" fill="var(--ink)"/>' +
      '<path d="M238 59l14-2-8 24z" fill="var(--g)"/>' +
      '<path d="M56 178l46-72 46 72z" fill="var(--g)"/>' +
      '<path d="M88 178l14-22 14 22z" fill="var(--card)" opacity=".85"/>' +
      '<path d="M102 106v-16" stroke="var(--ink)" stroke-width="3"/>' +
      '<path d="M102 90l20 6-20 6z" fill="var(--g)"/>' +
      '<path d="M172 178l52-80 52 80z" fill="var(--ink)"/>' +
      '<path d="M208 178l16-24 16 24z" fill="var(--card)" opacity=".8"/>' +
      '<path d="M224 98v-16" stroke="var(--ink)" stroke-width="3"/>' +
      '<path d="M224 82l20 6-20 6z" fill="var(--g)"/>' +
      '<rect x="42" y="178" width="236" height="10" rx="5" fill="var(--ink)"/>' +
    '</symbol>' +

    /* ---------- 7. товар --------------------------------------------------- */
    '<symbol id="ic-goods" viewBox="0 0 320 240">' +
      '<circle cx="160" cy="126" r="86" fill="var(--g-soft)" opacity=".5"/>' +
      '<path d="M112 108l32-20h128l-32 20z" fill="var(--g)"/>' +
      '<path d="M240 108l32-20v72l-32 20z" fill="var(--g-soft)"/>' +
      '<rect x="112" y="108" width="128" height="72" rx="4" fill="var(--ink)"/>' +
      '<rect x="168" y="108" width="14" height="72" fill="var(--card)" opacity=".9"/>' +
      '<path d="M200 88h14l-32 20h-14z" fill="var(--card)" opacity=".9"/>' +
      '<rect x="126" y="124" width="34" height="24" rx="2" fill="var(--card)"/>' +
      '<path d="M132 132h20M132 140h12" stroke="var(--g)" stroke-width="3"/>' +
      '<path d="M126 156v14M132 156v14M139 156v14M147 156v14M154 156v14" stroke="var(--card)" stroke-width="3" opacity=".85"/>' +
    '</symbol>' +

    /* ---------- 8. продукт ------------------------------------------------- */
    '<symbol id="ic-food" viewBox="0 0 320 240">' +
      '<circle cx="160" cy="126" r="86" fill="var(--g-soft)" opacity=".5"/>' +
      '<path d="M112 138c0-32 96-32 96 0" fill="none" stroke="var(--ink)" stroke-width="5"/>' +
      '<rect x="206" y="94" width="26" height="44" rx="6" fill="var(--card)" stroke="var(--ink)" stroke-width="4"/>' +
      '<rect x="212" y="84" width="14" height="12" rx="3" fill="var(--g)"/>' +
      '<ellipse cx="164" cy="126" rx="34" ry="18" fill="var(--ink)"/>' +
      '<path d="M146 120h36M150 130h28" stroke="var(--card)" stroke-width="3" opacity=".65"/>' +
      '<circle cx="116" cy="120" r="20" fill="var(--g)"/>' +
      '<path d="M116 100c0-8 6-12 12-12" fill="none" stroke="var(--ink)" stroke-width="4" stroke-linecap="round"/>' +
      '<path d="M82 138h156l-16 60H98z" fill="var(--g-soft)" stroke="var(--ink)" stroke-width="5" stroke-linejoin="round"/>' +
      '<path d="M118 152v32M146 152v32M174 152v32M202 152v32" stroke="var(--ink)" stroke-width="3" opacity=".35"/>' +
      '<path d="M98 170h124" stroke="var(--ink)" stroke-width="3" opacity=".25"/>' +
    '</symbol>' +

    /* ---------- 9. одежда -------------------------------------------------- */
    '<symbol id="ic-clothes" viewBox="0 0 320 240">' +
      '<circle cx="160" cy="126" r="86" fill="var(--g-soft)" opacity=".5"/>' +
      '<path d="M160 80c0-12 14-13 14-4" fill="none" stroke="var(--ink)" stroke-width="5" stroke-linecap="round"/>' +
      '<path d="M160 80l-40 18M160 80l40 18" stroke="var(--ink)" stroke-width="5"/>' +
      '<path d="M120 98h80" stroke="var(--ink)" stroke-width="5"/>' +
      '<path d="M128 100L94 118 80 140 104 154 122 140 122 190Q122 198 130 198H190Q198 198 198 190V140L216 154 240 140 226 118 192 100Q176 116 160 116Q144 116 128 100Z" ' +
        'fill="var(--g)" stroke="var(--ink)" stroke-width="5" stroke-linejoin="round"/>' +
      '<path d="M122 172h76" stroke="var(--card)" stroke-width="9" opacity=".55"/>' +
      '<path d="M160 116v56" stroke="var(--card)" stroke-width="3" opacity=".4"/>' +
    '</symbol>' +

    /* ---------- 10. обувь -------------------------------------------------- */
    '<symbol id="ic-shoes" viewBox="0 0 320 240">' +
      '<circle cx="160" cy="126" r="86" fill="var(--g-soft)" opacity=".5"/>' +
      '<ellipse cx="160" cy="197" rx="86" ry="7" fill="var(--ink)" opacity=".1"/>' +
      '<g transform="translate(62,-34)" opacity=".95">' +
        '<path d="M62 166C62 146 74 136 94 134L132 130C146 128 156 120 168 120C182 120 190 132 192 146L194 166Z" ' +
          'fill="var(--g-soft)" stroke="var(--ink)" stroke-width="4" stroke-linejoin="round"/>' +
        '<rect x="56" y="164" width="144" height="22" rx="11" fill="var(--ink)"/>' +
      '</g>' +
      '<path d="M62 166C62 146 74 136 94 134L132 130C146 128 156 120 168 120C182 120 190 132 192 146L194 166Z" ' +
        'fill="var(--g)" stroke="var(--ink)" stroke-width="4" stroke-linejoin="round"/>' +
      '<rect x="56" y="164" width="144" height="22" rx="11" fill="var(--ink)"/>' +
      '<path d="M64 168h128" stroke="var(--card)" stroke-width="3" opacity=".35"/>' +
      '<path d="M108 142l12 8M120 138l12 8M132 134l11 8" stroke="var(--card)" stroke-width="3.5" stroke-linecap="round"/>' +
      '<path d="M80 166c3-11 9-18 18-21" stroke="var(--ink)" stroke-width="3" opacity=".3" fill="none"/>' +
    '</symbol>' +

    /* ---------- 11. сувенир ------------------------------------------------ */
    '<symbol id="ic-souvenir" viewBox="0 0 320 240">' +
      '<circle cx="160" cy="126" r="86" fill="var(--g-soft)" opacity=".5"/>' +
      '<path d="M240 130c15 0 25 12 25 26 0 18-11 26-25 26s-25-8-25-26c0-14 10-26 25-26z" fill="var(--g-soft)"/>' +
      '<circle cx="240" cy="124" r="12" fill="var(--g-soft)"/>' +
      '<path d="M160 60c20 0 36 14 36 32 0 9-5 14 0 24 12 22 18 42 10 58-7 14-26 20-46 20s-39-6-46-20c-8-16-2-36 10-58 5-10 0-15 0-24 0-18 16-32 36-32z" fill="var(--g)"/>' +
      '<ellipse cx="160" cy="96" rx="22" ry="24" fill="var(--card)"/>' +
      '<path d="M120 94Q160 56 200 94L192 108Q160 78 128 108Z" fill="var(--ink)"/>' +
      '<circle cx="151" cy="100" r="3" fill="var(--ink)"/>' +
      '<circle cx="169" cy="100" r="3" fill="var(--ink)"/>' +
      '<path d="M154 110q6 5 12 0" fill="none" stroke="var(--ink)" stroke-width="3" stroke-linecap="round"/>' +
      '<circle cx="136" cy="108" r="5" fill="var(--g)" opacity=".45"/>' +
      '<circle cx="184" cy="108" r="5" fill="var(--g)" opacity=".45"/>' +
      '<circle cx="160" cy="150" r="9" fill="var(--card)" opacity=".9"/>' +
      '<circle cx="136" cy="166" r="6" fill="var(--card)" opacity=".6"/>' +
      '<circle cx="184" cy="166" r="6" fill="var(--card)" opacity=".6"/>' +
      '<circle cx="160" cy="176" r="5" fill="var(--card)" opacity=".5"/>' +
      '<ellipse cx="160" cy="212" rx="52" ry="7" fill="var(--ink)" opacity=".12"/>' +
    '</symbol>' +

    /* ---------- 12. упаковка ----------------------------------------------- */
    '<symbol id="ic-pack" viewBox="0 0 320 240">' +
      '<circle cx="160" cy="126" r="86" fill="var(--g-soft)" opacity=".5"/>' +
      '<g transform="rotate(-8 98 127)">' +
        '<rect x="52" y="96" width="92" height="62" rx="6" fill="var(--card)" stroke="var(--ink)" stroke-width="4"/>' +
        '<g fill="var(--g-soft)">' +
          '<circle cx="70" cy="112" r="4"/><circle cx="90" cy="112" r="4"/><circle cx="110" cy="112" r="4"/><circle cx="128" cy="112" r="4"/>' +
          '<circle cx="70" cy="128" r="4"/><circle cx="90" cy="128" r="4"/><circle cx="110" cy="128" r="4"/><circle cx="128" cy="128" r="4"/>' +
          '<circle cx="70" cy="144" r="4"/><circle cx="90" cy="144" r="4"/><circle cx="110" cy="144" r="4"/><circle cx="128" cy="144" r="4"/>' +
        '</g>' +
      '</g>' +
      '<rect x="120" y="112" width="124" height="86" rx="6" fill="var(--g-soft)" stroke="var(--ink)" stroke-width="5"/>' +
      '<rect x="172" y="112" width="18" height="86" fill="var(--card)" opacity=".92"/>' +
      '<rect x="120" y="146" width="124" height="14" fill="var(--card)" opacity=".92"/>' +
      '<circle cx="254" cy="152" r="30" fill="var(--g)" stroke="var(--ink)" stroke-width="5"/>' +
      '<circle cx="254" cy="152" r="12" fill="var(--card)"/>' +
      '<path d="M254 122v10" stroke="var(--card)" stroke-width="5" stroke-linecap="round"/>' +
    '</symbol>' +

    /* ---------- 13. цена --------------------------------------------------- */
    '<symbol id="ic-price" viewBox="0 0 320 240">' +
      '<circle cx="160" cy="126" r="86" fill="var(--g-soft)" opacity=".5"/>' +
      '<path d="M62 68c26 6 40 22 44 44" fill="none" stroke="var(--ink)" stroke-width="3"/>' +
      '<g transform="rotate(-10 168 126)">' +
        '<path d="M118 84H222a14 14 0 0 1 14 14V148a14 14 0 0 1-14 14H118L76 126Z" ' +
          'fill="var(--g)" stroke="var(--ink)" stroke-width="6" stroke-linejoin="round"/>' +
        '<circle cx="110" cy="126" r="9" fill="var(--card)" stroke="var(--ink)" stroke-width="5"/>' +
        '<path d="M182 104v46" stroke="var(--ink)" stroke-width="9" stroke-linecap="round"/>' +
        '<path d="M182 104a11 11 0 0 1 0 22" fill="none" stroke="var(--ink)" stroke-width="9"/>' +
        '<path d="M166 142h28" stroke="var(--ink)" stroke-width="9" stroke-linecap="round"/>' +
      '</g>' +
    '</symbol>' +

    /* ---------- 14. скидка ------------------------------------------------- */
    '<symbol id="ic-discount" viewBox="0 0 320 240">' +
      '<circle cx="160" cy="126" r="86" fill="var(--g-soft)" opacity=".5"/>' +
      '<g transform="rotate(-12 116 124)">' +
        '<path d="M96 82h66a14 14 0 0 1 14 14v56a14 14 0 0 1-14 14H96L58 124Z" ' +
          'fill="var(--g-soft)" stroke="var(--ink)" stroke-width="6" stroke-linejoin="round"/>' +
        '<circle cx="90" cy="124" r="8" fill="var(--card)" stroke="var(--ink)" stroke-width="4"/>' +
        '<path d="M112 112h30M112 124h20" stroke="var(--ink)" stroke-width="4" opacity=".45"/>' +
      '</g>' +
      '<circle cx="228" cy="108" r="44" fill="var(--g)" stroke="var(--ink)" stroke-width="6"/>' +
      '<circle cx="214" cy="94" r="8" fill="none" stroke="var(--ink)" stroke-width="6"/>' +
      '<circle cx="240" cy="122" r="8" fill="none" stroke="var(--ink)" stroke-width="6"/>' +
      '<path d="M206 130l44-42" stroke="var(--ink)" stroke-width="7" stroke-linecap="round"/>' +
    '</symbol>' +

    /* ---------- 15. стоимость ---------------------------------------------- */
    '<symbol id="ic-cost" viewBox="0 0 320 240">' +
      '<circle cx="160" cy="126" r="86" fill="var(--g-soft)" opacity=".5"/>' +
      '<rect x="92" y="62" width="118" height="140" rx="14" fill="var(--ink)"/>' +
      '<rect x="106" y="78" width="90" height="34" rx="5" fill="var(--card)"/>' +
      '<path d="M114 96h30M152 96h12" stroke="var(--g)" stroke-width="6" stroke-linecap="round"/>' +
      '<g fill="var(--card)" opacity=".9">' +
        '<circle cx="122" cy="132" r="6"/><circle cx="150" cy="132" r="6"/><circle cx="178" cy="132" r="6"/>' +
        '<circle cx="122" cy="158" r="6"/><circle cx="150" cy="158" r="6"/><circle cx="178" cy="158" r="6"/>' +
        '<circle cx="122" cy="184" r="6"/><circle cx="150" cy="184" r="6"/>' +
      '</g>' +
      '<circle cx="178" cy="184" r="6" fill="var(--g)"/>' +
      '<ellipse cx="248" cy="164" rx="28" ry="9" fill="var(--g)" stroke="var(--ink)" stroke-width="3"/>' +
      '<ellipse cx="248" cy="174" rx="28" ry="9" fill="var(--g)" stroke="var(--ink)" stroke-width="3"/>' +
      '<ellipse cx="248" cy="184" rx="28" ry="9" fill="var(--g)" stroke="var(--ink)" stroke-width="3"/>' +
      '<circle cx="248" cy="152" r="12" fill="var(--card)" opacity=".55"/>' +
    '</symbol>' +

    /* ---------- 16. количество --------------------------------------------- */
    '<symbol id="ic-amount" viewBox="0 0 320 240">' +
      '<circle cx="160" cy="126" r="86" fill="var(--g-soft)" opacity=".5"/>' +
      '<rect x="72" y="64" width="176" height="124" rx="12" fill="var(--g-soft)" stroke="var(--ink)" stroke-width="6"/>' +
      '<path d="M82 90h156M82 118h156M82 146h156M82 174h156" stroke="var(--ink)" stroke-width="4"/>' +
      '<g>' +
        '<circle cx="100" cy="90" r="10" fill="var(--g)"/>' +
        '<circle cx="126" cy="90" r="10" fill="var(--card)" stroke="var(--ink)" stroke-width="3"/>' +
        '<circle cx="152" cy="90" r="10" fill="var(--g)"/>' +
        '<circle cx="180" cy="90" r="10" fill="var(--g)"/>' +
        '<circle cx="206" cy="90" r="10" fill="var(--card)" stroke="var(--ink)" stroke-width="3"/>' +
        '<circle cx="96" cy="118" r="10" fill="var(--card)" stroke="var(--ink)" stroke-width="3"/>' +
        '<circle cx="124" cy="118" r="10" fill="var(--g)"/>' +
        '<circle cx="150" cy="118" r="10" fill="var(--g)"/>' +
        '<circle cx="192" cy="118" r="10" fill="var(--card)" stroke="var(--ink)" stroke-width="3"/>' +
        '<circle cx="218" cy="118" r="10" fill="var(--g)"/>' +
        '<circle cx="104" cy="146" r="10" fill="var(--g)"/>' +
        '<circle cx="132" cy="146" r="10" fill="var(--card)" stroke="var(--ink)" stroke-width="3"/>' +
        '<circle cx="158" cy="146" r="10" fill="var(--g)"/>' +
        '<circle cx="186" cy="146" r="10" fill="var(--g)"/>' +
        '<circle cx="212" cy="146" r="10" fill="var(--card)" stroke="var(--ink)" stroke-width="3"/>' +
        '<circle cx="92" cy="174" r="10" fill="var(--g)"/>' +
        '<circle cx="120" cy="174" r="10" fill="var(--g)"/>' +
        '<circle cx="146" cy="174" r="10" fill="var(--card)" stroke="var(--ink)" stroke-width="3"/>' +
        '<circle cx="174" cy="174" r="10" fill="var(--g)"/>' +
        '<circle cx="214" cy="174" r="10" fill="var(--card)" stroke="var(--ink)" stroke-width="3"/>' +
      '</g>' +
    '</symbol>' +

    /* ---------- 17. оптом -------------------------------------------------- */
    '<symbol id="ic-wholesale" viewBox="0 0 320 240">' +
      '<circle cx="160" cy="126" r="86" fill="var(--g-soft)" opacity=".5"/>' +
      '<g fill="var(--g)">' +
        '<rect x="72" y="128" width="54" height="46" rx="4"/>' +
        '<rect x="134" y="128" width="54" height="46" rx="4"/>' +
        '<rect x="196" y="128" width="54" height="46" rx="4"/>' +
      '</g>' +
      '<g fill="var(--ink)">' +
        '<rect x="103" y="82" width="54" height="46" rx="4"/>' +
        '<rect x="165" y="82" width="54" height="46" rx="4"/>' +
      '</g>' +
      '<g fill="var(--card)" opacity=".85">' +
        '<rect x="95" y="128" width="8" height="46"/>' +
        '<rect x="157" y="128" width="8" height="46"/>' +
        '<rect x="219" y="128" width="8" height="46"/>' +
        '<rect x="126" y="82" width="8" height="46"/>' +
        '<rect x="188" y="82" width="8" height="46"/>' +
      '</g>' +
      '<rect x="60" y="174" width="200" height="14" rx="3" fill="var(--ink)"/>' +
      '<g fill="var(--ink)">' +
        '<rect x="66" y="188" width="34" height="10" rx="3"/>' +
        '<rect x="116" y="188" width="34" height="10" rx="3"/>' +
        '<rect x="166" y="188" width="34" height="10" rx="3"/>' +
        '<rect x="216" y="188" width="34" height="10" rx="3"/>' +
      '</g>' +
    '</symbol>' +

    /* ---------- 18. в розницу ---------------------------------------------- */
    '<symbol id="ic-retail" viewBox="0 0 320 240">' +
      '<circle cx="160" cy="126" r="86" fill="var(--g-soft)" opacity=".5"/>' +
      '<path d="M206 92c-8-16-2-26 6-30" fill="none" stroke="var(--ink)" stroke-width="3"/>' +
      '<path d="M214 92h40a10 10 0 0 1 10 10v34a10 10 0 0 1-10 10h-40l-16-27z" ' +
        'fill="var(--card)" stroke="var(--ink)" stroke-width="4" stroke-linejoin="round"/>' +
      '<circle cx="214" cy="119" r="4" fill="var(--ink)"/>' +
      '<path d="M228 110h22M228 120h14" stroke="var(--g)" stroke-width="4" stroke-linecap="round"/>' +
      '<path d="M238 148c-6 8-18 12-30 12" fill="none" stroke="var(--g)" stroke-width="4" stroke-linecap="round"/>' +
      '<rect x="128" y="104" width="66" height="72" rx="6" fill="var(--g)" stroke="var(--ink)" stroke-width="5"/>' +
      '<rect x="174" y="104" width="10" height="72" fill="var(--card)" opacity=".85"/>' +
      '<rect x="142" y="120" width="30" height="20" rx="2" fill="var(--card)"/>' +
      '<path d="M148 128h16M148 134h10" stroke="var(--g)" stroke-width="3"/>' +
      '<rect x="96" y="176" width="160" height="10" rx="5" fill="var(--ink)"/>' +
      '<circle cx="100" cy="96" r="20" fill="var(--ink)"/>' +
      '<text x="100" y="104" text-anchor="middle" font-family="Segoe UI, Arial, sans-serif" font-size="24" font-weight="700" fill="var(--card)">1</text>' +
    '</symbol>' +

    /* ---------- 19. купить ------------------------------------------------- */
    '<symbol id="ic-buy" viewBox="0 0 320 240">' +
      '<circle cx="160" cy="126" r="86" fill="var(--g-soft)" opacity=".5"/>' +
      '<circle cx="234" cy="148" r="26" fill="var(--card)" stroke="var(--ink)" stroke-width="5"/>' +
      '<circle cx="234" cy="148" r="11" fill="var(--g)"/>' +
      '<path d="M100 112h116l-10 84c-1 7-7 12-14 12H124c-7 0-13-5-14-12z" ' +
        'fill="var(--g)" stroke="var(--ink)" stroke-width="5" stroke-linejoin="round"/>' +
      '<path d="M132 112V96c0-17 12-28 28-28s28 11 28 28v16" fill="none" stroke="var(--ink)" stroke-width="5"/>' +
      '<path d="M124 140h68" stroke="var(--card)" stroke-width="5" opacity=".8"/>' +
      '<path d="M134 166h48" stroke="var(--card)" stroke-width="4" opacity=".45"/>' +
    '</symbol>' +

    /* ---------- 20. продать ------------------------------------------------ */
    '<symbol id="ic-sell" viewBox="0 0 320 240">' +
      '<circle cx="160" cy="126" r="86" fill="var(--g-soft)" opacity=".5"/>' +
      '<path d="M160 76h62" stroke="var(--g)" stroke-width="8" stroke-linecap="round"/>' +
      '<path d="M220 62l24 14-24 14z" fill="var(--g)"/>' +
      '<rect x="88" y="112" width="66" height="40" rx="4" fill="var(--g)" stroke="var(--ink)" stroke-width="4"/>' +
      '<rect x="114" y="112" width="12" height="40" fill="var(--card)" opacity=".85"/>' +
      '<rect x="66" y="152" width="188" height="12" rx="4" fill="var(--ink)"/>' +
      '<rect x="74" y="164" width="10" height="30" fill="var(--ink)"/>' +
      '<rect x="236" y="164" width="10" height="30" fill="var(--ink)"/>' +
      '<g transform="rotate(-10 196 132)">' +
        '<rect x="164" y="120" width="64" height="30" rx="4" fill="var(--card)" stroke="var(--ink)" stroke-width="4"/>' +
        '<circle cx="196" cy="135" r="8" fill="var(--g)"/>' +
      '</g>' +
      '<g transform="rotate(8 218 112)">' +
        '<rect x="192" y="98" width="60" height="28" rx="4" fill="var(--card)" stroke="var(--ink)" stroke-width="4"/>' +
        '<path d="M204 112h20" stroke="var(--g)" stroke-width="3"/>' +
      '</g>' +
    '</symbol>' +

    /* ---------- 21. заказать ----------------------------------------------- */
    '<symbol id="ic-order" viewBox="0 0 320 240">' +
      '<circle cx="160" cy="126" r="86" fill="var(--g-soft)" opacity=".5"/>' +
      '<rect x="106" y="62" width="112" height="142" rx="8" fill="var(--card)" stroke="var(--ink)" stroke-width="5"/>' +
      '<rect x="142" y="52" width="40" height="20" rx="7" fill="var(--ink)"/>' +
      '<g fill="none" stroke="var(--ink)" stroke-width="3">' +
        '<rect x="120" y="96" width="13" height="13" rx="2"/>' +
        '<rect x="120" y="120" width="13" height="13" rx="2"/>' +
        '<rect x="120" y="144" width="13" height="13" rx="2"/>' +
        '<rect x="120" y="168" width="13" height="13" rx="2"/>' +
      '</g>' +
      '<path d="M139 102h58M139 126h44M139 150h58M139 174h32" stroke="var(--g)" stroke-width="5" stroke-linecap="round"/>' +
      '<path d="M123 102l4 4 6-7M123 126l4 4 6-7" fill="none" stroke="var(--ink)" stroke-width="3" stroke-linecap="round"/>' +
      '<g transform="rotate(18 246 140)">' +
        '<rect x="238" y="92" width="14" height="86" rx="3" fill="var(--g)"/>' +
        '<path d="M238 92h14v8h-14z" fill="var(--ink)"/>' +
        '<path d="M238 178l7 20 7-20z" fill="var(--ink)"/>' +
      '</g>' +
    '</symbol>' +

    /* ---------- 22. оплатить ----------------------------------------------- */
    '<symbol id="ic-pay" viewBox="0 0 320 240">' +
      '<circle cx="160" cy="126" r="86" fill="var(--g-soft)" opacity=".5"/>' +
      '<rect x="88" y="66" width="104" height="140" rx="16" fill="var(--ink)"/>' +
      '<rect x="102" y="82" width="76" height="46" rx="5" fill="var(--card)"/>' +
      '<path d="M112 96h26M112 110h40" stroke="var(--g)" stroke-width="5" stroke-linecap="round"/>' +
      '<g fill="var(--card)" opacity=".9">' +
        '<circle cx="112" cy="150" r="6.5"/><circle cx="132" cy="150" r="6.5"/><circle cx="152" cy="150" r="6.5"/>' +
        '<circle cx="112" cy="170" r="6.5"/><circle cx="132" cy="170" r="6.5"/><circle cx="152" cy="170" r="6.5"/>' +
        '<circle cx="112" cy="190" r="6.5"/><circle cx="132" cy="190" r="6.5"/>' +
      '</g>' +
      '<circle cx="152" cy="190" r="6.5" fill="var(--g)"/>' +
      '<g transform="rotate(-14 234 132)">' +
        '<rect x="188" y="104" width="94" height="58" rx="8" fill="var(--g)" stroke="var(--ink)" stroke-width="5"/>' +
        '<rect x="188" y="118" width="94" height="12" fill="var(--ink)"/>' +
        '<rect x="202" y="140" width="20" height="14" rx="3" fill="var(--card)" opacity=".9"/>' +
      '</g>' +
      '<circle cx="256" cy="82" r="20" fill="var(--g)" stroke="var(--ink)" stroke-width="4"/>' +
      '<path d="M247 82l6 6 12-12" fill="none" stroke="var(--card)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>' +
    '</symbol>' +

    /* ---------- 23. касса -------------------------------------------------- */
    '<symbol id="ic-cashier" viewBox="0 0 320 240">' +
      '<circle cx="160" cy="126" r="86" fill="var(--g-soft)" opacity=".5"/>' +
      '<rect x="88" y="128" width="140" height="62" rx="10" fill="var(--ink)"/>' +
      '<rect x="88" y="190" width="140" height="8" rx="3" fill="var(--ink)" opacity=".55"/>' +
      '<rect x="106" y="92" width="70" height="44" rx="6" fill="var(--g)" stroke="var(--ink)" stroke-width="4"/>' +
      '<path d="M116 108h30M116 120h18" stroke="var(--card)" stroke-width="4" stroke-linecap="round"/>' +
      '<g fill="var(--card)" opacity=".9">' +
        '<circle cx="104" cy="146" r="5.5"/><circle cx="126" cy="146" r="5.5"/><circle cx="148" cy="146" r="5.5"/>' +
        '<circle cx="170" cy="146" r="5.5"/><circle cx="192" cy="146" r="5.5"/>' +
        '<circle cx="104" cy="166" r="5.5"/><circle cx="126" cy="166" r="5.5"/><circle cx="148" cy="166" r="5.5"/>' +
        '<circle cx="170" cy="166" r="5.5"/><circle cx="192" cy="166" r="5.5"/>' +
      '</g>' +
      '<path d="M196 96h34v58l-8.5-6-8.5 6-8.5-6-8.5 6z" fill="var(--card)" stroke="var(--ink)" stroke-width="4" stroke-linejoin="round"/>' +
      '<path d="M204 110h18M204 120h18M204 130h12" stroke="var(--g)" stroke-width="3"/>' +
      '<rect x="196" y="72" width="34" height="6" rx="3" fill="var(--ink)"/>' +
    '</symbol>' +

    /* ---------- 24. чек ---------------------------------------------------- */
    '<symbol id="ic-receipt" viewBox="0 0 320 240">' +
      '<circle cx="160" cy="126" r="86" fill="var(--g-soft)" opacity=".5"/>' +
      '<path d="M112 58h96v128l-8 8-8-8-8 8-8-8-8 8-8-8-8 8-8-8-8 8-8-8-8 8-8-8-8 8z" ' +
        'fill="var(--card)" stroke="var(--ink)" stroke-width="4" stroke-linejoin="round"/>' +
      '<path d="M126 84h68M126 100h48M126 116h68M126 132h30" stroke="var(--g)" stroke-width="5" stroke-linecap="round"/>' +
      '<path d="M126 152h68M126 166h34" stroke="var(--ink)" stroke-width="6" stroke-linecap="round"/>' +
      '<circle cx="240" cy="170" r="22" fill="var(--g)" stroke="var(--ink)" stroke-width="4"/>' +
      '<circle cx="240" cy="170" r="9" fill="var(--card)"/>' +
      '<path d="M240 34v18" stroke="var(--ink)" stroke-width="4" opacity=".25"/>' +
    '</symbol>' +

    /* ---------- 25. договор ------------------------------------------------ */
    '<symbol id="ic-contract" viewBox="0 0 320 240">' +
      '<circle cx="160" cy="126" r="86" fill="var(--g-soft)" opacity=".5"/>' +
      '<path d="M100 56h88l32 32v100a14 14 0 0 1-14 14H100a14 14 0 0 1-14-14V70a14 14 0 0 1 14-14z" ' +
        'fill="var(--card)" stroke="var(--ink)" stroke-width="5" stroke-linejoin="round"/>' +
      '<path d="M188 56l32 32h-32z" fill="var(--g-soft)" stroke="var(--ink)" stroke-width="4" stroke-linejoin="round"/>' +
      '<path d="M104 104h84M104 122h64M104 140h84M104 158h44" stroke="var(--ink)" stroke-width="4" opacity=".3" stroke-linecap="round"/>' +
      '<path d="M104 178c7-9 12 6 19-2s11 7 18-1" fill="none" stroke="var(--ink)" stroke-width="4" stroke-linecap="round"/>' +
      '<circle cx="186" cy="176" r="24" fill="var(--g)" stroke="var(--ink)" stroke-width="4"/>' +
      '<circle cx="186" cy="176" r="14" fill="none" stroke="var(--card)" stroke-width="3" opacity=".85"/>' +
    '</symbol>' +

    /* ---------- 26. сделка ------------------------------------------------- */
    '<symbol id="ic-deal" viewBox="0 0 320 240">' +
      '<circle cx="160" cy="126" r="86" fill="var(--g-soft)" opacity=".5"/>' +
      '<circle cx="104" cy="94" r="18" fill="var(--ink)"/>' +
      '<path d="M76 200c0-44 12-70 28-70s28 26 28 70z" fill="var(--g)"/>' +
      '<circle cx="216" cy="94" r="18" fill="var(--g)"/>' +
      '<path d="M188 200c0-44 12-70 28-70s28 26 28 70z" fill="var(--ink)"/>' +
      '<path d="M126 152h68" stroke="var(--g)" stroke-width="15" stroke-linecap="round"/>' +
      '<circle cx="160" cy="152" r="16" fill="var(--card)" stroke="var(--ink)" stroke-width="4"/>' +
      '<path d="M152 152l6 6 12-13" fill="none" stroke="var(--g)" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round"/>' +
      '<path d="M160 46l4 10 10 4-10 4-4 10-4-10-10-4 10-4z" fill="var(--g)"/>' +
      '<circle cx="92" cy="52" r="3.5" fill="var(--g)"/>' +
      '<circle cx="226" cy="50" r="3.5" fill="var(--ink)" opacity=".45"/>' +
    '</symbol>' +

    /* ---------- 27. поставка ----------------------------------------------- */
    '<symbol id="ic-delivery" viewBox="0 0 320 240">' +
      '<circle cx="160" cy="126" r="86" fill="var(--g-soft)" opacity=".5"/>' +
      '<path d="M32 130h12M26 144h12M32 158h12" stroke="var(--g)" stroke-width="4" stroke-linecap="round" opacity=".8"/>' +
      '<rect x="52" y="92" width="132" height="76" rx="4" fill="var(--g)"/>' +
      '<path d="M76 92v76M100 92v76M124 92v76M148 92v76M172 92v76" stroke="var(--ink)" stroke-width="3" opacity=".18"/>' +
      '<path d="M184 112h34l22 28v28h-56z" fill="var(--ink)"/>' +
      '<path d="M192 120h22l14 20h-36z" fill="var(--card)"/>' +
      '<rect x="192" y="158" width="42" height="8" rx="3" fill="var(--ink)"/>' +
      '<circle cx="90" cy="172" r="20" fill="var(--ink)"/>' +
      '<circle cx="90" cy="172" r="8" fill="var(--card)"/>' +
      '<circle cx="214" cy="172" r="20" fill="var(--ink)"/>' +
      '<circle cx="214" cy="172" r="8" fill="var(--card)"/>' +
      '<path d="M40 196h208" stroke="var(--ink)" stroke-width="5" opacity=".25" stroke-linecap="round"/>' +
      '<path d="M256 196h28" stroke="var(--ink)" stroke-width="5" opacity=".25" stroke-linecap="round"/>' +
    '</symbol>' +

    /* ---------- 28. спрос --------------------------------------------------- */
    '<symbol id="ic-demand" viewBox="0 0 320 240">' +
      '<circle cx="160" cy="126" r="86" fill="var(--g-soft)" opacity=".5"/>' +
      '<path d="M72 190h180" stroke="var(--ink)" stroke-width="5" stroke-linecap="round"/>' +
      '<rect x="88" y="150" width="30" height="40" rx="4" fill="var(--g-soft)"/>' +
      '<rect x="130" y="126" width="30" height="64" rx="4" fill="var(--g)"/>' +
      '<rect x="172" y="100" width="30" height="90" rx="4" fill="var(--g)"/>' +
      '<rect x="214" y="74" width="30" height="116" rx="4" fill="var(--ink)"/>' +
      '<path d="M84 132c36-8 76-28 132-52" fill="none" stroke="var(--g)" stroke-width="7" stroke-linecap="round"/>' +
      '<path d="M228 70l18-8-2 20z" fill="var(--g)"/>' +
    '</symbol>' +

    /* ---------- 29. реклама ------------------------------------------------ */
    '<symbol id="ic-ads" viewBox="0 0 320 240">' +
      '<circle cx="160" cy="126" r="86" fill="var(--g-soft)" opacity=".5"/>' +
      '<path d="M92 118l84-34v78z" fill="var(--g)"/>' +
      '<rect x="176" y="80" width="16" height="78" rx="7" fill="var(--ink)"/>' +
      '<rect x="106" y="124" width="24" height="46" rx="10" fill="var(--ink)"/>' +
      '<path d="M208 100c14 12 14 40 0 52M228 88c24 18 24 60 0 76" fill="none" stroke="var(--ink)" stroke-width="6" stroke-linecap="round" opacity=".8"/>' +
      '<circle cx="118" cy="62" r="22" fill="var(--card)" stroke="var(--ink)" stroke-width="4"/>' +
      '<circle cx="110" cy="55" r="4" fill="none" stroke="var(--ink)" stroke-width="3"/>' +
      '<circle cx="126" cy="69" r="4" fill="none" stroke="var(--ink)" stroke-width="3"/>' +
      '<path d="M106 72l20-20" stroke="var(--ink)" stroke-width="3"/>' +
    '</symbol>' +

    /* ---------- 30. качество ----------------------------------------------- */
    '<symbol id="ic-quality" viewBox="0 0 320 240">' +
      '<circle cx="160" cy="126" r="86" fill="var(--g-soft)" opacity=".5"/>' +
      '<path d="M116 184l-14 30 24-8z" fill="var(--ink)" opacity=".6"/>' +
      '<path d="M204 184l14 30-24-8z" fill="var(--ink)" opacity=".6"/>' +
      '<path d="M160 56l70 22v52c0 38-30 62-70 76-40-14-70-38-70-76V78z" ' +
        'fill="var(--g)" stroke="var(--ink)" stroke-width="5" stroke-linejoin="round"/>' +
      '<path d="M128 132l22 22 44-46" fill="none" stroke="var(--card)" stroke-width="12" stroke-linecap="round" stroke-linejoin="round"/>' +
    '</symbol>' +

    /* ---------- UI-иконки -------------------------------------------------- */
    '<symbol id="ui-speaker" viewBox="0 0 24 24">' +
      '<path d="M4 9.5h3.2L12 5.4v13.2l-4.8-4.1H4z" fill="currentColor"/>' +
      '<path d="M15.2 8.4a5 5 0 0 1 0 7.2M18 5.8a9 9 0 0 1 0 12.4" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>' +
    '</symbol>' +
    '<symbol id="ui-check" viewBox="0 0 24 24">' +
      '<path d="M4.5 12.5l5 5 10-11" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>' +
    '</symbol>' +
    '<symbol id="ui-x" viewBox="0 0 24 24">' +
      '<path d="M6 6l12 12M18 6L6 18" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/>' +
    '</symbol>' +
    '<symbol id="ui-arrow" viewBox="0 0 24 24">' +
      '<path d="M4 12h14M13 6l6 6-6 6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>' +
    '</symbol>' +
    '<symbol id="ui-play" viewBox="0 0 24 24">' +
      '<path d="M8 5l11 7-11 7z" fill="currentColor"/>' +
    '</symbol>' +
    '<symbol id="ui-stop" viewBox="0 0 24 24">' +
      '<rect x="6" y="6" width="12" height="12" rx="2" fill="currentColor"/>' +
    '</symbol>' +
    '<symbol id="ui-translate" viewBox="0 0 24 24">' +
      '<path d="M3.5 6h9M8 4v2c0 4.2-2.4 8-5.5 10M5.4 10.5c1.4 3 3.7 5 6.1 6" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/>' +
      '<path d="M12.5 20l3.8-9 3.8 9M13.9 17h4.8" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/>' +
    '</symbol>' +
    '<symbol id="ui-restart" viewBox="0 0 24 24">' +
      '<path d="M20 12a8 8 0 1 1-2.7-6M20 4.5V10h-5.5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>' +
    '</symbol>' +
    '<symbol id="ui-search" viewBox="0 0 24 24">' +
      '<circle cx="10.5" cy="10.5" r="6.5" fill="none" stroke="currentColor" stroke-width="2"/>' +
      '<path d="M15.5 15.5L21 21" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>' +
    '</symbol>' +
    '<symbol id="ui-bulb" viewBox="0 0 24 24">' +
      '<path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-3.5 10.9c.6.4.9 1 .9 1.7v.4h5.2v-.4c0-.7.3-1.3.9-1.7A6 6 0 0 0 12 3z" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/>' +
    '</symbol>' +
    '<symbol id="ui-trophy" viewBox="0 0 24 24">' +
      '<path d="M7 4h10v5a5 5 0 0 1-10 0zM7 5H4v2a3 3 0 0 0 3 3M17 5h3v2a3 3 0 0 1-3 3M12 14v4M8 21h8M9.5 18h5" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/>' +
    '</symbol>' +
    '<symbol id="ui-tag" viewBox="0 0 24 24">' +
      '<path d="M3 12.8V5.5A2.5 2.5 0 0 1 5.5 3h7.3L21 11.2 12.8 19.5z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/>' +
      '<circle cx="8" cy="8" r="1.7" fill="currentColor"/>' +
    '</symbol>' +

    /* ---------- Сцена для первого экрана ---------------------------------- */
    '<symbol id="hero-market" viewBox="0 0 720 520">' +
      '<circle cx="452" cy="238" r="196" fill="var(--gold-tint)"/>' +
      '<circle cx="250" cy="356" r="120" fill="var(--rust-tint)" opacity=".7"/>' +
      '<path d="M36 74Q360 132 684 66" fill="none" stroke="var(--ink)" stroke-width="3" opacity=".45"/>' +
      '<path d="M87 81l26 0-13 26z" fill="var(--gold)"/>' +
      '<path d="M167 90l26 1-13 26z" fill="var(--rust)"/>' +
      '<path d="M257 97l26 1-13 26z" fill="var(--ink)"/>' +
      '<path d="M347 99l26 0-13 26z" fill="var(--gold)"/>' +
      '<path d="M437 96l26-1-13 26z" fill="var(--rust)"/>' +
      '<path d="M527 88l26-1-13 26z" fill="var(--ink)"/>' +
      '<path d="M607 76l26-2-13 26z" fill="var(--gold)"/>' +
      '<rect x="236" y="196" width="14" height="176" fill="var(--ink)"/>' +
      '<rect x="574" y="196" width="14" height="176" fill="var(--ink)"/>' +
      '<circle cx="245" cy="188" r="33" fill="var(--rust)"/>' +
      '<circle cx="311" cy="188" r="33" fill="var(--gold)"/>' +
      '<circle cx="378" cy="188" r="33" fill="var(--rust)"/>' +
      '<circle cx="444" cy="188" r="33" fill="var(--gold)"/>' +
      '<circle cx="511" cy="188" r="33" fill="var(--rust)"/>' +
      '<circle cx="578" cy="188" r="33" fill="var(--gold)"/>' +
      '<rect x="212" y="148" width="400" height="40" fill="var(--rust)"/>' +
      '<g fill="var(--card)" opacity=".28">' +
        '<rect x="252" y="148" width="9" height="40"/>' +
        '<rect x="318" y="148" width="9" height="40"/>' +
        '<rect x="384" y="148" width="9" height="40"/>' +
        '<rect x="450" y="148" width="9" height="40"/>' +
        '<rect x="516" y="148" width="9" height="40"/>' +
      '</g>' +
      '<rect x="312" y="94" width="200" height="50" rx="10" fill="var(--ink)"/>' +
      '<text x="412" y="128" text-anchor="middle" font-family="Georgia, Times New Roman, serif" font-size="24" letter-spacing="2.5" fill="var(--paper-2)">ТОРГОВЛЯ</text>' +
      '<path d="M280 188v22M544 188v26" stroke="var(--ink)" stroke-width="3"/>' +
      '<g transform="rotate(-8 280 236)">' +
        '<rect x="252" y="210" width="56" height="38" rx="7" fill="var(--card)" stroke="var(--ink)" stroke-width="4"/>' +
        '<circle cx="262" cy="221" r="4" fill="var(--ink)"/>' +
        '<path d="M272 240h24M272 230h14" stroke="var(--rust)" stroke-width="4" stroke-linecap="round"/>' +
      '</g>' +
      '<g transform="rotate(-6 544 238)">' +
        '<rect x="514" y="214" width="60" height="38" rx="7" fill="var(--gold)" stroke="var(--ink)" stroke-width="4"/>' +
        '<path d="M524 234h22" stroke="var(--ink)" stroke-width="4" stroke-linecap="round"/>' +
      '</g>' +
      /* продавец за прилавком */
      '<circle cx="400" cy="262" r="18" fill="var(--ink)"/>' +
      '<rect x="393" y="276" width="14" height="18" fill="var(--ink)"/>' +
      '<path d="M372 336c0-30 13-46 28-46s28 16 28 46z" fill="var(--forest)"/>' +
      '<path d="M387 304h26v32h-26z" fill="var(--card)" opacity=".85"/>' +
      /* матрёшка на прилавке */
      '<g transform="translate(430 240) scale(.55)">' +
        '<path d="M160 60c20 0 36 14 36 32 0 9-5 14 0 24 12 22 18 42 10 58-7 14-26 20-46 20s-39-6-46-20c-8-16-2-36 10-58 5-10 0-15 0-24 0-18 16-32 36-32z" fill="var(--rust)"/>' +
        '<ellipse cx="160" cy="96" rx="22" ry="24" fill="var(--card)"/>' +
        '<path d="M120 94Q160 56 200 94L192 108Q160 78 128 108Z" fill="var(--ink)"/>' +
        '<circle cx="151" cy="100" r="3" fill="var(--ink)"/>' +
        '<circle cx="169" cy="100" r="3" fill="var(--ink)"/>' +
        '<circle cx="160" cy="150" r="9" fill="var(--card)" opacity=".9"/>' +
      '</g>' +
      '<rect x="216" y="336" width="396" height="26" fill="var(--ink)"/>' +
      '<rect x="228" y="362" width="372" height="70" fill="var(--gold-tint)"/>' +
      '<g stroke="var(--gold)" stroke-width="2" opacity=".35">' +
        '<path d="M264 362v70M312 362v70M360 362v70M408 362v70M456 362v70M504 362v70M552 362v70"/>' +
      '</g>' +
      '<path d="M228 424h372" stroke="var(--ink)" stroke-width="4" opacity=".12"/>' +
      '<rect x="250" y="296" width="96" height="40" rx="4" fill="var(--ink)"/>' +
      '<path d="M250 308h96" stroke="var(--card)" stroke-width="3" opacity=".3"/>' +
      '<circle cx="274" cy="288" r="11" fill="var(--rust)"/>' +
      '<circle cx="300" cy="288" r="11" fill="var(--rust)"/>' +
      '<circle cx="326" cy="288" r="11" fill="var(--rust)"/>' +
      '<g transform="translate(96 330)">' +
        '<path d="M0 0h104l-8 86c-1 6-6 10-12 10H20c-6 0-11-4-12-10z" fill="var(--forest)"/>' +
        '<path d="M26 0v-14c0-14 10-24 26-24s26 10 26 24V0" fill="none" stroke="var(--ink)" stroke-width="6"/>' +
        '<path d="M16 32h72" stroke="var(--card)" stroke-width="6" opacity=".7"/>' +
        '<circle cx="52" cy="62" r="10" fill="var(--card)" opacity=".35"/>' +
      '</g>' +
      '<circle cx="620" cy="252" r="26" fill="var(--gold)" stroke="var(--ink)" stroke-width="4"/>' +
      '<circle cx="620" cy="252" r="10" fill="var(--card)" opacity=".6"/>' +
      '<circle cx="660" cy="302" r="17" fill="var(--gold-soft)" stroke="var(--ink)" stroke-width="4"/>' +
      '<g transform="rotate(10 606 392)">' +
        '<rect x="556" y="362" width="100" height="60" rx="10" fill="var(--rust)" stroke="var(--ink)" stroke-width="4"/>' +
        '<text x="606" y="404" text-anchor="middle" font-family="Segoe UI, Arial, sans-serif" font-size="30" font-weight="700" fill="var(--card)">−20%</text>' +
      '</g>' +
      '<ellipse cx="400" cy="450" rx="290" ry="14" fill="var(--ink)" opacity=".08"/>' +
    '</symbol>' +

    '</svg>';

  function inject() {
    if (document.getElementById('icon-sprite')) return;
    document.body.insertAdjacentHTML('afterbegin', SPRITE);
  }

  function markup(id, cls) {
    return '<svg class="' + (cls || 'ic') + '" aria-hidden="true" focusable="false"><use href="#' + id + '"></use></svg>';
  }

  return { inject: inject, svg: markup, sprite: SPRITE };
})();

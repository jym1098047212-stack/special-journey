/* ==========================================================================
   Торговля · 贸易 — логика сайта
   Без библиотек и сборки. Всё работает локально, в том числе с file://
   ========================================================================== */
(function () {
  'use strict';

  var D = window.SITE_DATA;
  var ICON = window.ICONS.svg;

  var $ = function (sel, root) { return (root || document).querySelector(sel); };
  var $$ = function (sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); };

  var stripStress = function (s) { return String(s).replace(/\u0301/g, ''); };

  var esc = function (s) {
    return String(s).replace(/[&<>"]/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
    });
  };

  function shuffle(arr) {
    for (var i = arr.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1));
      var t = arr[i]; arr[i] = arr[j]; arr[j] = t;
    }
    return arr;
  }

  function sample(arr, n) { return shuffle(arr.slice()).slice(0, n); }

  var storage = {
    get: function (key, fallback) {
      try {
        var raw = window.localStorage.getItem(key);
        return raw === null ? fallback : JSON.parse(raw);
      } catch (e) { return fallback; }
    },
    set: function (key, value) {
      try { window.localStorage.setItem(key, JSON.stringify(value)); } catch (e) { /* приватный режим */ }
    }
  };

  var reducedMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ------------------------------------------------------------------ */
  /* Озвучивание (встроенный синтез речи браузера)                       */
  /* ------------------------------------------------------------------ */
  var TTS = (function () {
    var supported = 'speechSynthesis' in window && 'SpeechSynthesisUtterance' in window;
    var voice = null;

    function pickVoice() {
      if (!supported) return;
      var voices = window.speechSynthesis.getVoices() || [];
      voice = voices.filter(function (v) { return /^ru/i.test(v.lang); })[0] || null;
    }

    if (supported) {
      pickVoice();
      if (typeof window.speechSynthesis.addEventListener === 'function') {
        window.speechSynthesis.addEventListener('voiceschanged', pickVoice);
      } else {
        window.speechSynthesis.onvoiceschanged = pickVoice;
      }
    }

    function speak(text, opts) {
      if (!supported || !text) return null;
      opts = opts || {};
      try { window.speechSynthesis.cancel(); } catch (e) { /* ignore */ }
      var u = new SpeechSynthesisUtterance(text);
      u.lang = 'ru-RU';
      u.rate = opts.rate || 0.92;
      u.pitch = 1;
      if (voice) u.voice = voice;
      if (opts.onend) u.onend = opts.onend;
      u.onerror = function (event) {
        var type = event && event.error;
        if (type && type !== 'interrupted' && type !== 'canceled') warnTts();
        if (opts.onerror) opts.onerror(event);
      };
      window.speechSynthesis.speak(u);
      return u;
    }

    function stop() {
      if (supported) { try { window.speechSynthesis.cancel(); } catch (e) { /* ignore */ } }
    }

    return { supported: supported, speak: speak, stop: stop, voice: function () { return voice; } };
  })();

  if (!TTS.supported) {
    document.body.classList.add('no-tts');
    var note = $('#tts-note');
    if (note) note.hidden = false;
  }

  var ttsWarned = false;
  function warnTts() {
    if (ttsWarned) return;
    ttsWarned = true;
    var el = $('#tts-note');
    if (el) el.hidden = false;
  }

  function speakerIcon(cls) {
    return '<svg class="ic ' + (cls || '') + '" aria-hidden="true" focusable="false"><use href="#ui-speaker"></use></svg>';
  }

  function icon(id, cls) {
    return '<svg class="ic ' + (cls || '') + '" aria-hidden="true" focusable="false"><use href="#' + id + '"></use></svg>';
  }

  /* ------------------------------------------------------------------ */
  /* Данные                                                              */
  /* ------------------------------------------------------------------ */
  var WORDS = D.words.map(function (w) {
    return {
      id: w.id, ru: w.ru, plain: stripStress(w.ru), pos: w.pos, zh: w.zh,
      group: w.group, icon: w.icon, ex: w.ex, exZh: w.exZh, note: w.note
    };
  });

  var GROUP = {};
  D.groups.forEach(function (g) { GROUP[g.id] = g; });

  var WORD_BY_ID = {};
  WORDS.forEach(function (w) { WORD_BY_ID[w.id] = w; });

  /* ------------------------------------------------------------------ */
  /* Прогресс: выученные слова                                           */
  /* ------------------------------------------------------------------ */
  var Learned = {
    ids: new Set(storage.get('torgovlya:learned', [])),
    has: function (id) { return this.ids.has(id); },
    toggle: function (id) {
      if (this.ids.has(id)) this.ids.delete(id); else this.ids.add(id);
      storage.set('torgovlya:learned', Array.from(this.ids));
      this.update();
    },
    count: function () {
      return WORDS.filter(function (w) { return Learned.ids.has(w.id); }).length;
    },
    update: function () {
      var n = this.count();
      var total = WORDS.length;
      var countEl = $('#learned-count');
      var fillEl = $('#learned-fill');
      if (countEl) countEl.textContent = n;
      if (fillEl) fillEl.style.width = (total ? (n / total) * 100 : 0) + '%';
    }
  };

  /* ------------------------------------------------------------------ */
  /* Отрисовка: первый экран и схема группы                              */
  /* ------------------------------------------------------------------ */
  function renderHeroArt() {
    var host = $('#hero-art');
    if (!host) return;
    host.innerHTML =
      '<svg viewBox="0 0 720 520" role="img" aria-label="Рыночный прилавок: навес, ящик с яблоками, ценники, монеты и сумка">' +
        '<use href="#hero-market"></use>' +
      '</svg>';
  }

  function renderField() {
    var branches = D.groups.map(function (g, i) {
      var ws = WORDS.filter(function (w) { return w.group === g.id; });
      var examples = ws.slice(0, 3).map(function (w) { return w.ru; }).join(' · ');
      return '' +
        '<button class="branch" type="button" data-g="' + g.id + '" data-filter="' + g.id + '">' +
          '<span class="branch__idx">0' + (i + 1) + '</span>' +
          '<span class="branch__main">' +
            '<span class="branch__ru">' + g.ru + '</span>' +
            '<span class="branch__zh" lang="zh-CN">' + g.zh + '</span>' +
          '</span>' +
          '<span class="branch__count">' + ws.length + ' слов</span>' +
          '<span class="branch__ex">' + examples + '</span>' +
        '</button>';
    }).join('');

    $('#field').innerHTML =
      '<div class="field-core">' +
        '<div>' +
          '<p class="field-core__label">гипероним · 上位词</p>' +
          '<p class="field-core__ru" lang="ru">торго́вля</p>' +
          '<p class="field-core__zh" lang="zh-CN">贸易 · 商业</p>' +
          '<p class="field-core__def">Обмен товарами и услугами между людьми, компаниями и странами.' +
            '<span lang="zh-CN">人与人、公司与国家之间的商品和服务交换。</span></p>' +
        '</div>' +
        '<div class="field-core__foot">' +
          '<p class="field-core__forms"><b>торгова́ть</b> · <b>торго́вый</b> · <b>торго́вец</b> · <b>торго́вый центр</b></p>' +
          '<p class="field-core__note">5 подгрупп · 30 слов · 12 сочетаний</p>' +
        '</div>' +
      '</div>' +
      '<div class="field-branches">' + branches + '</div>';
  }

  /* ------------------------------------------------------------------ */
  /* Словарь                                                             */
  /* ------------------------------------------------------------------ */
  var state = { filter: 'all', query: '' };

  function normalize(s) {
    return stripStress(String(s)).toLowerCase().replace(/\s+/g, ' ').trim();
  }

  function matchesQuery(w, q) {
    if (!q) return true;
    var hay = normalize([w.ru, w.zh, w.ex, w.exZh, w.note, w.pos].join(' '));
    return hay.indexOf(q) !== -1;
  }

  function renderFilters() {
    var chips = [{ id: 'all', label: 'Все', n: WORDS.length }].concat(
      D.groups.map(function (g) {
        return { id: g.id, label: g.ru, n: WORDS.filter(function (w) { return w.group === g.id; }).length };
      })
    );
    $('#vocab-filters').innerHTML = chips.map(function (c) {
      return '<button class="filter-chip" type="button" data-filter="' + c.id + '" aria-pressed="' + (state.filter === c.id) + '">' +
        c.label + '<span class="filter-chip__n">' + c.n + '</span>' +
      '</button>';
    }).join('');
  }

  function wordCard(w) {
    var g = GROUP[w.group];
    var learned = Learned.has(w.id);
    var say = esc(w.plain + '. ' + stripStress(w.ex));
    return '' +
      '<article class="word-card' + (learned ? ' is-learned' : '') + '" data-g="' + w.group + '" data-id="' + w.id + '">' +
        '<div class="word-card__media">' +
          ICON(w.icon, 'ic') +
          '<span class="word-card__tag">' + g.ru + '</span>' +
        '</div>' +
        '<div class="word-card__body">' +
          '<div class="word-card__head">' +
            '<h3 class="word-card__ru" lang="ru">' + w.ru + '</h3>' +
            '<span class="word-card__pos">' + w.pos + '</span>' +
          '</div>' +
          '<p class="word-card__zh" lang="zh-CN">' + w.zh + '</p>' +
          '<p class="word-card__ex" lang="ru">' + w.ex + '</p>' +
          '<p class="word-card__exzh" lang="zh-CN">' + w.exZh + '</p>' +
          '<details class="word-card__note">' +
            '<summary>Комментарий · 用法</summary>' +
            '<p lang="zh-CN">' + w.note + '</p>' +
          '</details>' +
        '</div>' +
        '<div class="word-card__actions">' +
          '<button class="speak" type="button" data-say="' + say + '" aria-label="Прослушать слово и пример: ' + esc(w.plain) + '">' + speakerIcon() + '</button>' +
          '<button class="learn-btn" type="button" aria-pressed="' + learned + '">' + (learned ? 'Выучено ✓' : 'Выучил') + '</button>' +
        '</div>' +
      '</article>';
  }

  function renderVocab() {
    var q = normalize(state.query);
    var list = WORDS.filter(function (w) {
      return (state.filter === 'all' || w.group === state.filter) && matchesQuery(w, q);
    });
    $('#word-grid').innerHTML = list.map(wordCard).join('');
    $('#vocab-empty').hidden = list.length > 0;
    $('#learned-total').textContent = WORDS.length;
    Learned.update();
  }

  function setFilter(id, scrollToVocab) {
    var hadChipFocus = document.activeElement && document.activeElement.classList.contains('filter-chip');
    state.filter = id;
    renderFilters();
    renderVocab();
    if (hadChipFocus) {
      var newChip = $('.filter-chip[data-filter="' + id + '"]');
      if (newChip) newChip.focus({ preventScroll: true });
    }
    if (scrollToVocab) {
      var target = $('#vocab');
      if (target) target.scrollIntoView({ behavior: reducedMotion ? 'auto' : 'smooth', block: 'start' });
    }
  }

  /* ------------------------------------------------------------------ */
  /* Сочетания и дополнительные слова                                    */
  /* ------------------------------------------------------------------ */
  function renderCollocs() {
    $('#colloc-grid').innerHTML = D.collocs.map(function (c, i) {
      return '' +
        '<article class="colloc" data-num="' + (i + 1 < 10 ? '0' : '') + (i + 1) + '">' +
          '<p class="colloc__ru" lang="ru">' + c.ru + '</p>' +
          '<p class="colloc__zh" lang="zh-CN">' + c.zh + '</p>' +
          '<p class="colloc__ex" lang="ru">' + c.ex + '</p>' +
          '<p class="colloc__exzh" lang="zh-CN">' + c.exZh + '</p>' +
        '</article>';
    }).join('');
  }

  function renderExtras() {
    $('#extras-body').innerHTML = D.extras.map(function (x) {
      return '<tr>' +
        '<td lang="ru">' + x.ru + '</td>' +
        '<td>' + x.pos + '</td>' +
        '<td lang="zh-CN">' + x.zh + '</td>' +
        '<td lang="ru">' + x.ex + '<span lang="zh-CN">' + x.exZh + '</span></td>' +
      '</tr>';
    }).join('');
  }

  /* ------------------------------------------------------------------ */
  /* Диалог                                                              */
  /* ------------------------------------------------------------------ */
  var dialogue = {
    playing: false,
    index: -1,
    stress: true,
    zh: true
  };

  function renderDialogue() {
    var d = D.dialogue;
    $('#dialogue-place').textContent = d.place;
    $('#dialogue-level').textContent = d.level;
    $('#dialogue-intro').textContent = d.intro;
    $('#dialogue-intro-zh').textContent = d.introZh;

    $('#dialogue-lines').innerHTML = d.lines.map(function (line, i) {
      var sp = d.speakers[line.who];
      var plain = stripStress(line.ru);
      return '' +
        '<div class="line line--' + line.who + '" data-line="' + i + '">' +
          '<span class="avatar" aria-hidden="true">' + sp.avatar + '</span>' +
          '<div class="bubble">' +
            '<div class="bubble__top">' +
              '<span class="bubble__name">' + sp.name + ' <span lang="zh-CN">' + sp.zh + '</span></span>' +
              '<button class="speak speak--sm" type="button" data-say="' + esc(plain) + '" aria-label="Прослушать реплику ' + (i + 1) + '">' +
                speakerIcon() +
              '</button>' +
            '</div>' +
            '<p class="bubble__ru" lang="ru" data-stressed="' + esc(line.ru) + '" data-plain="' + esc(plain) + '">' + line.ru + '</p>' +
            '<p class="bubble__zh" lang="zh-CN">' + line.zh + '</p>' +
            (line.tip ? '<p class="bubble__tip">' + icon('ui-bulb') + '<span lang="zh-CN">' + line.tip + '</span></p>' : '') +
          '</div>' +
        '</div>';
    }).join('');

    $('#dialogue-gloss').innerHTML =
      '<p class="glossary__title">Слова и выражения из диалога · 对话中的词语</p>' +
      d.gloss.map(function (g) {
        return '<span class="gloss-chip"><b lang="ru">' + g.ru + '</b><span lang="zh-CN">' + g.zh + '</span></span>';
      }).join('');
  }

  function setDialogueZh(on) {
    dialogue.zh = on;
    var box = $('#dialogue');
    box.classList.toggle('hide-zh', !on);
    var btn = $('#toggle-dialogue-zh');
    btn.setAttribute('aria-pressed', String(on));
  }

  function setStress(on) {
    dialogue.stress = on;
    $$('.bubble__ru').forEach(function (p) {
      p.textContent = on ? p.getAttribute('data-stressed') : p.getAttribute('data-plain');
    });
    $('#toggle-stress').setAttribute('aria-pressed', String(on));
  }

  function highlightLine(idx) {
    $$('.line').forEach(function (line, i) {
      line.classList.toggle('is-playing', i === idx);
    });
    var active = $('.line[data-line="' + idx + '"]');
    if (active) {
      var r = active.getBoundingClientRect();
      if (r.top < 90 || r.bottom > window.innerHeight - 40) {
        active.scrollIntoView({ behavior: reducedMotion ? 'auto' : 'smooth', block: 'center' });
      }
    }
  }

  function stopDialogue() {
    dialogue.playing = false;
    TTS.stop();
    highlightLine(-1);
    var btn = $('#play-dialogue');
    if (btn) {
      btn.setAttribute('aria-pressed', 'false');
      var label = btn.querySelector('span');
      if (label) label.textContent = 'Прослушать диалог';
    }
  }

  function playDialogue() {
    if (!TTS.supported) return;
    if (dialogue.playing) { stopDialogue(); return; }

    dialogue.playing = true;
    dialogue.index = -1;
    var btn = $('#play-dialogue');
    btn.setAttribute('aria-pressed', 'true');
    btn.querySelector('span').textContent = 'Остановить';

    function next() {
      if (!dialogue.playing) return;
      dialogue.index += 1;
      if (dialogue.index >= D.dialogue.lines.length) { stopDialogue(); return; }
      var idx = dialogue.index;
      highlightLine(idx);
      var text = stripStress(D.dialogue.lines[idx].ru).replace(/^—\s*/, '');
      TTS.speak(text, {
        rate: 0.9,
        onend: function () { if (dialogue.playing) window.setTimeout(next, 240); },
        onerror: function () { stopDialogue(); }
      });
    }
    next();
  }

  /* ------------------------------------------------------------------ */
  /* Текст и вопросы к нему                                              */
  /* ------------------------------------------------------------------ */
  function renderReader() {
    var r = D.reader;
    $('#reader-title').textContent = r.title;
    $('#reader-title-zh').textContent = r.titleZh;
    $('#reader-level').textContent = r.level;

    $('#reader-body').innerHTML = r.paragraphs.map(function (p) {
      return '<div class="para">' +
        '<p class="para__ru" lang="ru">' + p.ru + '</p>' +
        '<p class="para__zh" lang="zh-CN">' + p.zh + '</p>' +
      '</div>';
    }).join('');

    $('#reader-gloss').innerHTML =
      '<p class="glossary__title">Слова к тексту · 文中词语</p>' +
      r.gloss.map(function (g) {
        return '<span class="gloss-chip"><b lang="ru">' + g.ru + '</b><span lang="zh-CN">' + g.zh + '</span></span>';
      }).join('');
  }

  function setReaderZh(on) {
    var reader = $('#reader');
    reader.classList.toggle('show-zh', on);
    var btn = $('#toggle-text-zh');
    btn.setAttribute('aria-pressed', String(on));
    btn.querySelector('span').textContent = on ? 'Скрыть перевод' : 'Показать перевод';
  }

  var checkState = { right: 0, answered: 0 };

  function renderCheck() {
    $('#check-questions').innerHTML = D.reader.questions.map(function (q, qi) {
      return '<div class="check-q" data-q="' + qi + '">' +
        '<p class="check-q__title"><span class="check-q__num">' + (qi + 1) + '.</span><span>' + q.q + '</span></p>' +
        '<div class="check-opts">' +
          q.options.map(function (o, oi) {
            return '<button class="check-opt" type="button" data-qi="' + qi + '" data-oi="' + oi + '">' + o + '</button>';
          }).join('') +
        '</div>' +
        '<p class="check-fb" id="check-fb-' + qi + '" aria-live="polite"></p>' +
      '</div>';
    }).join('');
  }

  function answerCheck(btn) {
    var qi = Number(btn.dataset.qi);
    var oi = Number(btn.dataset.oi);
    var q = D.reader.questions[qi];
    var box = $('.check-q[data-q="' + qi + '"]');
    if (!q || !box || box.dataset.done) return;
    box.dataset.done = '1';

    var ok = oi === q.correct;
    var opts = $$('.check-opt', box);
    opts.forEach(function (b, i) {
      b.disabled = true;
      if (i === q.correct) b.classList.add('is-correct');
      else if (i === oi) b.classList.add('is-wrong');
      else b.classList.add('is-dim');
    });

    var fb = $('#check-fb-' + qi);
    fb.classList.add('is-shown', ok ? 'is-ok' : 'is-bad');
    fb.innerHTML = (ok ? '<b>Верно.</b> ' : '<b>Не совсем.</b> Правильный ответ: «' + q.options[q.correct] + '». ') + q.explain;

    checkState.answered += 1;
    if (ok) checkState.right += 1;
    $('#check-score').innerHTML = 'Верно: ' + checkState.right + ' / ' + checkState.answered +
      ' <span lang="zh-CN">· 正确 ' + checkState.right + ' 题</span>';
  }

  /* ------------------------------------------------------------------ */
  /* Тест                                                                */
  /* ------------------------------------------------------------------ */
  var KEYS = ['А', 'Б', 'В', 'Г'];

  var Quiz = {
    mode: 'mixed',
    qs: [],
    i: 0,
    score: 0,
    answers: [],
    locked: false,
    fromRetry: false
  };

  function speakerBtn(w) {
    return '<button class="speak" type="button" data-say="' + esc(w.plain) + '" aria-label="Прослушать слово">' + speakerIcon() + '</button>';
  }

  /* Похожи ли китайские переводы: не ставим в один вопрос «集市» и «市场, 集市» */
  function zhSimilar(a, b) {
    var A = String(a).replace(/[，,、；;\s（）()]/g, '');
    var B = String(b).replace(/[，,、；;\s（）()]/g, '');
    if (!A || !B) return false;
    if (A === B) return true;
    for (var i = 0; i < A.length - 1; i++) {
      if (B.indexOf(A.slice(i, i + 2)) !== -1) return true;
    }
    return false;
  }

  function pickDistractors(w) {
    var others = WORDS.filter(function (x) { return x.id !== w.id; });
    var notSimilar = function (x) { return !zhSimilar(x.zh, w.zh); };
    var same = shuffle(others.filter(function (x) { return x.group === w.group && notSimilar(x); }));
    var rest = shuffle(others.filter(function (x) { return x.group !== w.group && notSimilar(x); }));
    var pool = same.concat(rest);
    if (pool.length < 3) pool = pool.concat(shuffle(others.filter(notSimilar)));
    return pool.slice(0, 3);
  }

  function buildMeaning(w) {
    var distractors = pickDistractors(w).map(function (x) { return x.zh; });
    return {
      type: 'meaning',
      kind: 'Лексика',
      typeName: 'значение слова',
      stem: 'Что значит слово?',
      promptHtml: '<span class="q-word" lang="ru">' + w.ru + '</span>' + speakerBtn(w),
      options: shuffle([{ text: w.zh, ok: true }].concat(distractors.map(function (t) { return { text: t, ok: false }; }))),
      explain: w.note,
      short: w.ru + ' · ' + w.zh,
      resultTitle: '<span lang="ru">' + w.ru + '</span>',
      resultSub: 'значение слова',
      correctText: w.zh
    };
  }

  function buildReverse(w) {
    var distractors = pickDistractors(w).map(function (x) { return x.ru; });
    return {
      type: 'reverse',
      kind: 'Лексика',
      typeName: 'перевод на русский',
      stem: 'Как сказать по-русски?',
      /* Без кнопки озвучивания: аудио выдало бы правильный ответ */
      promptHtml: '<span class="q-zh" lang="zh-CN">' + w.zh + '</span>',
      options: shuffle([{ text: w.ru, ok: true }].concat(distractors.map(function (t) { return { text: t, ok: false }; }))),
      explain: w.note,
      short: w.zh + ' · ' + w.ru,
      resultTitle: '<span lang="zh-CN">' + w.zh + '</span>',
      resultSub: 'перевод на русский',
      correctText: w.ru
    };
  }

  function buildImage(w) {
    var distractors = pickDistractors(w).map(function (x) { return x.ru; });
    return {
      type: 'image',
      kind: 'Картинки',
      typeName: 'что на картинке',
      stem: 'Что на картинке?',
      promptHtml: '<div class="q-media" data-g="' + w.group + '" role="img" aria-label="Иллюстрация к заданию">' + ICON(w.icon, 'ic') + '</div>',
      options: shuffle([{ text: w.ru, ok: true }].concat(distractors.map(function (t) { return { text: t, ok: false }; }))),
      explain: w.note,
      short: w.ru + ' · ' + w.zh,
      resultTitle: '<span class="result-thumb" data-g="' + w.group + '">' + ICON(w.icon, 'ic') + '</span><span lang="ru">' + w.ru + '</span>',
      resultSub: 'картинка',
      correctText: w.ru
    };
  }

  function buildGap(g) {
    var blank = '<span class="blank" role="img" aria-label="пропуск"></span>';
    var options = g.options.map(function (t, i) { return { text: t, ok: i === g.correct }; });
    return {
      type: 'gap',
      kind: 'Контекст',
      typeName: 'слово в предложении',
      stem: 'Вставьте пропущенное слово',
      promptHtml: '<p class="q-sentence" lang="ru">' + g.sentence.replace('___', blank) + '</p>',
      options: shuffle(options),
      explain: g.explain,
      short: g.sentence.replace('___', '…'),
      resultTitle: '<span lang="ru">' + g.sentence.replace('___', '…') + '</span>',
      resultSub: 'пропуск в предложении',
      correctText: g.options[g.correct],
      fullRu: g.sentence.replace('___', g.options[g.correct]),
      fullZh: g.zh
    };
  }

  function pickQuestions(mode) {
    if (mode === 'context') {
      return sample(D.gaps, 10).map(buildGap);
    }
    var words = shuffle(WORDS.slice());
    if (mode === 'vocab') {
      return shuffle(
        words.slice(0, 5).map(buildMeaning)
          .concat(words.slice(5, 8).map(buildReverse))
          .concat(words.slice(8, 10).map(buildImage))
      );
    }
    return shuffle(
      words.slice(0, 3).map(buildMeaning)
        .concat(words.slice(3, 5).map(buildReverse))
        .concat(words.slice(5, 7).map(buildImage))
        .concat(sample(D.gaps, 3).map(buildGap))
    );
  }

  function updateQuizBest() {
    var best = storage.get('torgovlya:best', null);
    var el = $('#quiz-best');
    if (!el) return;
    el.innerHTML = best === null ? '' : 'Лучший результат: <b>' + best + '%</b> · 最好成绩';
  }

  function renderQuizModes() {
    $('#quiz-modes').innerHTML = D.modes.map(function (m) {
      return '<button class="mode-card" type="button" data-mode="' + m.id + '" aria-pressed="' + (m.id === 'mixed') + '">' +
        '<span class="mode-card__ru">' + m.ru + ' <span class="mode-card__zh" lang="zh-CN">' + m.zh + '</span></span>' +
        '<span class="mode-card__desc">' + m.desc + '</span>' +
        '<span class="mode-card__detail">' + m.detail + '</span>' +
      '</button>';
    }).join('');
  }

  function renderHud() {
    var n = Quiz.qs.length;
    var hud = $('.quiz-hud');
    if (!hud) return;
    hud.querySelector('.hud-count').innerHTML = 'Вопрос <b>' + (Quiz.i + 1) + '</b> / ' + n;
    hud.querySelector('.hud-score').textContent = '✓ ' + Quiz.score;
    var bar = hud.querySelector('.hud-bar > span');
    if (bar) bar.style.width = (Quiz.i / n) * 100 + '%';
  }

  function renderQuestion() {
    var q = Quiz.qs[Quiz.i];
    var n = Quiz.qs.length;
    var stage = $('#quiz-stage');
    var optLang = q.type === 'meaning' ? 'zh-CN' : 'ru';

    stage.innerHTML =
      '<div class="quiz-hud">' +
        '<span class="hud-count">Вопрос <b>1</b> / ' + n + '</span>' +
        '<span class="hud-bar" aria-hidden="true"><span></span></span>' +
        '<span class="hud-score">✓ 0</span>' +
      '</div>' +
      '<div class="quiz-question">' +
        '<div class="q-meta"><span>' + q.kind + '</span><span>' + q.typeName + '</span></div>' +
        '<p class="q-stem">' + q.stem + '</p>' +
        '<div class="q-prompt">' + q.promptHtml + '</div>' +
        '<div class="q-options" role="group" aria-label="Варианты ответа">' +
          q.options.map(function (o, i) {
            return '<button class="option" type="button" data-opt="' + i + '">' +
              '<span class="option__key">' + KEYS[i] + '</span>' +
              '<span lang="' + optLang + '">' + o.text + '</span>' +
            '</button>';
          }).join('') +
        '</div>' +
        '<div class="q-feedback" id="q-feedback" aria-live="polite"></div>' +
        '<div class="q-actions">' +
          '<button class="btn btn--dark" type="button" id="q-next" hidden>' +
            (Quiz.i === n - 1 ? 'Показать результат' : 'Далее') +
            icon('ui-arrow', 'ic--sm') +
          '</button>' +
        '</div>' +
      '</div>';

    renderHud();

    $$('.option', stage).forEach(function (btn) {
      btn.addEventListener('click', function () { answerQuestion(Number(btn.dataset.opt)); });
    });
    $('#q-next').addEventListener('click', nextQuestion);
    Quiz.locked = false;

    var qbox = $('.quiz-question', stage);
    if (qbox) {
      qbox.setAttribute('tabindex', '-1');
      qbox.focus({ preventScroll: true });
    }
  }

  function answerQuestion(idx) {
    if (Quiz.locked) return;
    Quiz.locked = true;

    var q = Quiz.qs[Quiz.i];
    var chosen = q.options[idx];
    var ok = !!chosen.ok;
    if (ok) Quiz.score += 1;
    Quiz.answers.push({ q: q, ok: ok, chosen: chosen.text });

    var buttons = $$('#quiz-stage .option');
    buttons.forEach(function (btn, i) {
      btn.disabled = true;
      var key = btn.querySelector('.option__key');
      if (q.options[i].ok) {
        btn.classList.add('is-correct');
        key.innerHTML = icon('ui-check');
      } else if (i === idx) {
        btn.classList.add('is-wrong');
        key.innerHTML = icon('ui-x');
      } else {
        btn.classList.add('is-dim');
      }
    });

    var hud = $('.quiz-hud');
    if (hud) {
      hud.querySelector('.hud-score').textContent = '✓ ' + Quiz.score;
      var bar = hud.querySelector('.hud-bar > span');
      if (bar) bar.style.width = ((Quiz.i + 1) / Quiz.qs.length) * 100 + '%';
    }

    var full = '';
    if (q.type === 'gap') {
      full = '<div class="feedback__full" lang="ru">' + q.fullRu +
             '<span lang="zh-CN">' + q.fullZh + '</span></div>';
    }

    var ansLang = q.type === 'meaning' ? 'zh-CN' : 'ru';
    $('#q-feedback').innerHTML =
      '<div class="feedback feedback--' + (ok ? 'ok' : 'bad') + '">' +
        '<span class="feedback__icon">' + icon(ok ? 'ui-check' : 'ui-x') + '</span>' +
        '<div>' +
          '<span class="feedback__title">' + (ok ? 'Верно!' : 'Не совсем') + '</span>' +
          (ok ? '' : '<p>Правильный ответ: <b lang="' + ansLang + '">' + q.correctText + '</b>.</p>') +
          '<p lang="zh-CN">' + q.explain + '</p>' +
          full +
        '</div>' +
      '</div>';

    var next = $('#q-next');
    next.hidden = false;
    next.focus();
  }

  function nextQuestion() {
    Quiz.i += 1;
    if (Quiz.i >= Quiz.qs.length) { finishQuiz(); return; }
    renderQuestion();
  }

  function verdictFor(pct) {
    if (pct >= 90) return { title: 'Отлично! <span lang="zh-CN">太棒了</span>', text: 'Вы уверенно владеете лексикой темы. Попробуйте другой режим или пройдите тест ещё раз — вопросы каждый раз новые.' };
    if (pct >= 70) return { title: 'Хорошо! <span lang="zh-CN">很好</span>', text: 'Основные слова вы знаете. Загляните в разбор ошибок и повторите те вопросы, где были сложности.' };
    if (pct >= 50) return { title: 'Неплохо, но есть над чем поработать <span lang="zh-CN">还需努力</span>', text: 'Вернитесь к словарю и сочетаниям, а затем пройдите тест ещё раз — особенно полезно повторить только ошибки.' };
    return { title: 'Пока не получилось <span lang="zh-CN">还需要多练</span>', text: 'Начните с карточек в словаре, отметьте выученные слова и попробуйте снова. Тест можно проходить сколько угодно раз.' };
  }

  function finishQuiz() {
    var total = Quiz.qs.length;
    var pct = Math.round((Quiz.score / total) * 100);
    var best = storage.get('torgovlya:best', null);
    if (best === null || pct > best) {
      best = pct;
      storage.set('torgovlya:best', best);
    }
    updateQuizBest();

    var wrong = Quiz.answers.filter(function (a) { return !a.ok; });
    var v = verdictFor(pct);
    var ringColor = pct >= 70 ? 'var(--forest)' : (pct >= 50 ? 'var(--gold)' : 'var(--rust)');

    $('#quiz-stage').hidden = true;
    var box = $('#quiz-result');
    box.hidden = false;
    box.innerHTML =
      '<div class="result-head">' +
        '<div class="score-ring" style="--p:0;--ring:' + ringColor + '"><div class="score-ring__val"><b>' + pct + '%</b><span>' + Quiz.score + ' из ' + total + '</span></div></div>' +
        '<div class="result-copy">' +
          '<h3>' + v.title + '</h3>' +
          '<p>' + v.text + '</p>' +
          '<div class="result-stats">' +
            '<div><b>' + Quiz.score + '</b><span>верно · 正确</span></div>' +
            '<div><b>' + (total - Quiz.score) + '</b><span>ошибок · 错误</span></div>' +
            '<div><b>' + best + '%</b><span>лучший · 最好</span></div>' +
          '</div>' +
        '</div>' +
      '</div>' +
      (wrong.length
        ? '<div class="result-list"><h4>Разбор ошибок · 错题回顾</h4>' +
            wrong.map(function (a) {
              var ansLang = a.q.type === 'meaning' ? 'zh-CN' : 'ru';
              return '<div class="result-item result-item--bad">' +
                '<span class="result-item__icon">' + icon('ui-x') + '</span>' +
                '<div class="result-item__body">' +
                  '<p class="result-item__q">' + (a.q.resultTitle || a.q.short) + '</p>' +
                  '<p class="result-item__a">' +
                    (a.q.resultSub ? '<span class="muted">' + a.q.resultSub + '</span>' : '') +
                    'Ваш ответ: <span lang="' + ansLang + '">' + a.chosen + '</span>. Правильно: <b lang="' + ansLang + '">' + a.q.correctText + '</b>' +
                  '</p>' +
                '</div>' +
              '</div>';
            }).join('') +
          '</div>'
        : '<p class="result-best">Ни одной ошибки — отличный результат! · 全部正确！</p>') +
      '<div class="result-actions">' +
        '<button class="btn btn--primary" type="button" data-quiz="restart">' + icon('ui-restart', 'ic--sm') + 'Пройти ещё раз</button>' +
        (wrong.length ? '<button class="btn btn--dark" type="button" data-quiz="retry">Повторить ошибки</button>' : '') +
        '<a class="btn btn--ghost" href="#vocab">К словарю</a>' +
      '</div>' +
      '<p class="result-best">Лучший результат сохраняется в этом браузере <span lang="zh-CN">· 最好成绩保存在本机浏览器中</span></p>';

    var ring = box.querySelector('.score-ring');
    if (ring) {
      if (reducedMotion) {
        ring.style.setProperty('--p', pct);
      } else {
        var value = 0;
        var tick = function () {
          value += 2;
          ring.style.setProperty('--p', Math.min(value, pct));
          if (value < pct) window.requestAnimationFrame(tick);
        };
        window.requestAnimationFrame(tick);
      }
    }

    box.setAttribute('tabindex', '-1');
    box.focus({ preventScroll: true });

    box.querySelectorAll('[data-quiz]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        if (btn.dataset.quiz === 'retry') {
          var retryQs = wrong.map(function (a) {
            var q = a.q;
            return Object.assign({}, q, {
              options: shuffle(q.options.map(function (o) { return { text: o.text, ok: o.ok }; }))
            });
          });
          beginQuiz('retry', retryQs);
        } else {
          beginQuiz(Quiz.fromRetry ? 'mixed' : Quiz.mode);
        }
      });
    });

    if (!reducedMotion) {
      $('#quiz-shell').scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }

  function beginQuiz(mode, customQuestions) {
    Quiz.mode = mode;
    Quiz.fromRetry = mode === 'retry';
    Quiz.qs = customQuestions || pickQuestions(mode);
    Quiz.i = 0;
    Quiz.score = 0;
    Quiz.answers = [];
    Quiz.locked = false;

    $('#quiz-start').hidden = true;
    $('#quiz-result').hidden = true;
    var stage = $('#quiz-stage');
    stage.hidden = false;
    renderQuestion();
    if (!reducedMotion) {
      $('#quiz-shell').scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }

  /* ------------------------------------------------------------------ */
  /* Подключение обработчиков                                            */
  /* ------------------------------------------------------------------ */
  function bindEvents() {
    /* Озвучивание по клику на динамик */
    document.addEventListener('click', function (e) {
      var btn = e.target.closest('[data-say]');
      if (!btn) return;
      if (!TTS.supported) return;
      e.preventDefault();
      if (dialogue.playing) stopDialogue();
      var text = btn.getAttribute('data-say');
      btn.classList.add('is-speaking');
      var remove = function () { btn.classList.remove('is-speaking'); };
      TTS.speak(text, { rate: 0.92, onend: remove, onerror: remove });
      window.setTimeout(remove, 9000);
    });

    /* Поиск */
    var search = $('#vocab-search');
    var timer = null;
    search.addEventListener('input', function () {
      window.clearTimeout(timer);
      timer = window.setTimeout(function () {
        state.query = search.value;
        renderVocab();
      }, 120);
    });

    /* Фильтры и схема группы */
    document.addEventListener('click', function (e) {
      var chip = e.target.closest('[data-filter]');
      if (!chip) return;
      var id = chip.getAttribute('data-filter');
      var isBranch = !!chip.closest('.branch');
      setFilter(id, isBranch);
    });

    /* Выученные слова */
    document.addEventListener('click', function (e) {
      var learn = e.target.closest('.learn-btn');
      if (!learn) return;
      var card = learn.closest('.word-card');
      if (!card) return;
      var id = card.getAttribute('data-id');
      Learned.toggle(id);
      var on = Learned.has(id);
      card.classList.toggle('is-learned', on);
      learn.setAttribute('aria-pressed', String(on));
      learn.textContent = on ? 'Выучено ✓' : 'Выучил';
    });

    /* Диалог */
    $('#play-dialogue').addEventListener('click', playDialogue);
    $('#toggle-dialogue-zh').addEventListener('click', function () {
      setDialogueZh(!dialogue.zh);
    });
    $('#toggle-stress').addEventListener('click', function () {
      setStress(!dialogue.stress);
    });

    /* Текст */
    $('#toggle-text-zh').addEventListener('click', function () {
      var on = !$('#reader').classList.contains('show-zh');
      setReaderZh(on);
    });

    /* Вопросы к тексту */
    $('#check-questions').addEventListener('click', function (e) {
      var btn = e.target.closest('.check-opt');
      if (btn) answerCheck(btn);
    });

    /* Тест: выбор режима */
    $('#quiz-modes').addEventListener('click', function (e) {
      var card = e.target.closest('.mode-card');
      if (!card) return;
      Quiz.mode = card.getAttribute('data-mode');
      $$('#quiz-modes .mode-card').forEach(function (c) {
        c.setAttribute('aria-pressed', String(c === card));
      });
    });

    $('#quiz-begin').addEventListener('click', function () {
      beginQuiz(Quiz.mode);
    });

    /* Размер шрифта */
    $$('[data-font]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var sizes = ['md', 'lg', 'xl'];
        var current = sizes.indexOf(document.documentElement.getAttribute('data-fs') || 'md');
        if (current < 0) current = 0;
        var next = btn.getAttribute('data-font') === 'inc'
          ? Math.min(sizes.length - 1, current + 1)
          : Math.max(0, current - 1);
        document.documentElement.setAttribute('data-fs', sizes[next]);
        storage.set('torgovlya:fs', next);
      });
    });

    /* Кнопка «к началу» в подвале и якоря */
    $$('a[href^="#"]').forEach(function (link) {
      link.addEventListener('click', function (e) {
        var id = link.getAttribute('href');
        if (id === '#top' || id === '#') return;
        var target = document.querySelector(id);
        if (!target) return;
        e.preventDefault();
        target.scrollIntoView({ behavior: reducedMotion ? 'auto' : 'smooth', block: 'start' });
        if (history.replaceState) history.replaceState(null, '', id);
      });
    });
  }

  /* ------------------------------------------------------------------ */
  /* Навигация, прогресс чтения, появление блоков                        */
  /* ------------------------------------------------------------------ */
  function initNav() {
    var sections = $$('main section[id]');
    var links = {};
    $$('.nav a, .footer-nav a').forEach(function (a) {
      links[a.getAttribute('href').slice(1)] = a;
    });

    if ('IntersectionObserver' in window) {
      var io = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          if (!entry.isIntersecting) return;
          var id = entry.target.id;
          $$('.nav a').forEach(function (a) {
            var on = a.getAttribute('href') === '#' + id;
            a.classList.toggle('is-active', on);
            if (on) a.setAttribute('aria-current', 'true');
            else a.removeAttribute('aria-current');
          });
        });
      }, { rootMargin: '-20% 0px -70% 0px', threshold: 0 });
      sections.forEach(function (s) { io.observe(s); });
    }
  }

  function initScrollProgress() {
    var bar = $('#scroll-bar');
    if (!bar) return;
    var update = function () {
      var h = document.documentElement;
      var max = h.scrollHeight - h.clientHeight;
      var p = max > 0 ? (h.scrollTop || document.body.scrollTop) / max : 0;
      bar.style.width = Math.min(100, Math.max(0, p * 100)) + '%';
    };
    window.addEventListener('scroll', update, { passive: true });
    window.addEventListener('resize', update);
    update();
  }

  function initReveal() {
    if (reducedMotion || !('IntersectionObserver' in window)) return;
    var targets = $$('.section-head, .word-card, .colloc, .about-card, .note-block, .extras, .field');
    targets.forEach(function (el) { el.classList.add('reveal'); });

    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-in');
          io.unobserve(entry.target);
        }
      });
    }, { rootMargin: '0px 0px -6% 0px', threshold: 0.05 });

    targets.forEach(function (el) { io.observe(el); });
  }

  /* ------------------------------------------------------------------ */
  /* Старт                                                               */
  /* ------------------------------------------------------------------ */
  function init() {
    window.ICONS.inject();
    renderHeroArt();
    renderField();
    renderFilters();
    renderVocab();
    renderCollocs();
    renderExtras();
    renderDialogue();
    renderReader();
    renderCheck();
    renderQuizModes();
    updateQuizBest();

    var savedFs = storage.get('torgovlya:fs', 0);
    var sizes = ['md', 'lg', 'xl'];
    document.documentElement.setAttribute('data-fs', sizes[savedFs] || 'md');

    bindEvents();
    initNav();
    initScrollProgress();
    Learned.update();

    if (D.dialogue.gloss.length) setDialogueZh(true);
    setReaderZh(false);
    initReveal();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
